// ==UserScript==
// @name         ia2 Letterboxd → ext.to / 1337x / Stremio Search
// @namespace    https://letterboxd.com
// @version      1.4.0
// @description  Adiciona botões nas páginas de filmes do Letterboxd para buscar no ext.to, no 1337x e abrir no Stremio
// @author       you
// @match        https://letterboxd.com/film/*
// @grant        GM_openInTab
// @grant        GM_xmlhttpRequest
// @connect      letterboxd.com
// @run-at       document-end
// ==/UserScript==

(function () {
  'use strict';

  function getFilmTitle() {
    const h1 = document.querySelector('h1.headline-1.js-widont');
    if (h1) return h1.textContent.trim();

    const meta = document.querySelector('meta[property="og:title"]');
    if (meta) {
      return meta.content.replace(/\s*[•·]\s*Letterboxd\s*$/i, '').replace(/\s*\(\d{4}\)\s*$/, '').trim();
    }

    return null;
  }

  function getFilmYear() {
    const selectors = [
      '.releaseyear a',
      '.release-year a',
      '.release-year',
      'a[href*="/films/year/"]',
      '.film-header-lockup .releaseyear',
    ];

    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el.textContent.replace(/[()]/g, '').trim();
    }

    const titleMatch = document.title.match(/\(((19|20)\d{2})\)/);
    if (titleMatch) return titleMatch[1];

    const ogTitle = document.querySelector('meta[property="og:title"]')?.content || '';
    const ogMatch = ogTitle.match(/\(((19|20)\d{2})\)/);
    if (ogMatch) return ogMatch[1];

    return '';
  }

  // 1. Extrai o IMDB ID do JSON-LD embutido na página (fonte mais fiável)
  function getImdbIdFromJsonLd() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const s of scripts) {
      try {
        const data = JSON.parse(s.textContent);
        // Pode estar em sameAs (array de URLs) ou em url directamente
        const urls = [].concat(data.sameAs || [], data.url || []);
        for (const u of urls) {
          const m = String(u).match(/(tt\d{7,8})/);
          if (m) return m[1];
        }
      } catch (e) { /* JSON inválido, ignora */ }
    }
    return null;
  }

  // 2. Link visível para imdb.com/title/ na página
  function getImdbIdFromDom() {
    const links = document.querySelectorAll('a[href*="imdb.com/title/tt"]');
    for (const a of links) {
      const m = a.href.match(/(tt\d{7,8})/);
      if (m) return m[1];
    }
    return null;
  }

  // 3. Fallback: busca a sub-página /details/ via GM_xmlhttpRequest (sem restrições CORS)
  function getImdbIdFromDetailsPage() {
    return new Promise((resolve) => {
      const slugMatch = location.pathname.match(/^\/film\/([^/]+)/);
      if (!slugMatch) return resolve(null);

      GM_xmlhttpRequest({
        method: 'GET',
        url: `https://letterboxd.com/film/${slugMatch[1]}/details/`,
        onload(res) {
          const m = res.responseText.match(/imdb\.com\/title\/(tt\d{7,8})/);
          resolve(m ? m[1] : null);
        },
        onerror() { resolve(null); },
      });
    });
  }

  function searchOnExtTo(title, year) {
    const query = year ? `${title} ${year} 1080p` : `${title} 1080p`;
    const url = `https://ext.to/browse/?page_size=100&q=${encodeURIComponent(query)}&with_adult=0`;
    GM_openInTab(url, { active: true });
  }

  function searchOn1337x(title, year) {
    const query = year ? `${title} ${year} 1080p` : `${title} 1080p`;
    const url = `https://1337x.to/search/${encodeURIComponent(query)}/1/`;
    GM_openInTab(url, { active: true });
  }

  async function openInStremio() {
    // Tenta as três fontes em ordem de fiabilidade
    let imdbId = getImdbIdFromJsonLd()
             || getImdbIdFromDom()
             || await getImdbIdFromDetailsPage();

    if (imdbId) {
      console.log(`[Letterboxd→Stremio] IMDB ID: ${imdbId}`);
      window.location.href = `stremio:///detail/movie/${imdbId}`;
    } else {
      const title = getFilmTitle();
      if (!title) {
        alert('[Letterboxd → Stremio] Não foi possível detectar o título ou IMDB ID do filme.');
        return;
      }
      console.warn('[Letterboxd→Stremio] IMDB ID não encontrado, usando busca por título.');
      GM_openInTab(`https://web.stremio.com/#/search?search=${encodeURIComponent(title)}`, { active: true });
    }
  }

  function handleSearch(site) {
    if (site === 'stremio') {
      openInStremio();
      return;
    }

    const title = getFilmTitle();
    if (!title) {
      alert('[Letterboxd Search] Não foi possível detectar o título do filme.');
      return;
    }
    const year = getFilmYear().replace(/[()]/g, '').trim();

    if (site === 'extto') searchOnExtTo(title, year);
    if (site === '1337x') searchOn1337x(title, year);
  }

  function createButton({ label, title, color, hoverColor, site, svgIcon }) {
    const btn = document.createElement('button');
    btn.title = title;

    const defaultIcon = `
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
           viewBox="0 0 24 24" fill="none" stroke="currentColor"
           stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
           style="display:inline;vertical-align:-2px;margin-right:5px">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>`;

    btn.innerHTML = `${svgIcon || defaultIcon}${label}`;

    Object.assign(btn.style, {
      display:        'inline-flex',
      alignItems:     'center',
      justifyContent: 'center',
      padding:        '6px 14px',
      background:     color,
      color:          '#fff',
      border:         'none',
      borderRadius:   '4px',
      cursor:         'pointer',
      fontSize:       '12px',
      fontWeight:     '700',
      letterSpacing:  '0.05em',
      textTransform:  'uppercase',
      transition:     'background 0.2s',
    });

    btn.addEventListener('mouseenter', () => btn.style.background = hoverColor);
    btn.addEventListener('mouseleave', () => btn.style.background = color);
    btn.addEventListener('click', () => handleSearch(site));

    return btn;
  }

  // Ícone de play (Stremio)
  const stremioIcon = `
    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
         viewBox="0 0 24 24" fill="currentColor"
         style="display:inline;vertical-align:-2px;margin-right:5px">
      <path d="M8 5v14l11-7z"/>
    </svg>`;

  function injectButtons() {
    if (document.getElementById('letterboxd-search-btns')) return;

    const targets = [
      '.film-rating-wrapper',
      '.film-actions',
      '.col-17 .details',
      'section.film-header-lockup',
      '.film-header-group',
    ];

    let anchor = null;
    for (const sel of targets) {
      anchor = document.querySelector(sel);
      if (anchor) break;
    }

    if (!anchor) {
      anchor = document.querySelector('#content') || document.body;
    }

    const wrapper = document.createElement('div');
    wrapper.id = 'letterboxd-search-btns';
    wrapper.style.cssText = 'margin:8px 0 4px; display:flex; gap:8px; flex-wrap:wrap;';

    wrapper.appendChild(createButton({
      label:      'ext.to',
      title:      'Buscar no ext.to',
      color:      '#00c030',
      hoverColor: '#00a828',
      site:       'extto',
    }));

    wrapper.appendChild(createButton({
      label:      '1337x',
      title:      'Buscar no 1337x',
      color:      '#e05a00',
      hoverColor: '#c04e00',
      site:       '1337x',
    }));

    wrapper.appendChild(createButton({
      label:      'Stremio',
      title:      'Abrir no Stremio',
      color:      '#7b3fe4',
      hoverColor: '#6a32c8',
      site:       'stremio',
      svgIcon:    stremioIcon,
    }));

    anchor.insertAdjacentElement('afterend', wrapper);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectButtons);
  } else {
    injectButtons();
  }

  let lastPath = location.pathname;
  const observer = new MutationObserver(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      setTimeout(injectButtons, 800);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

})();