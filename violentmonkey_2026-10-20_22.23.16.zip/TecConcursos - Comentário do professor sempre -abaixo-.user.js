// ==UserScript==
// @name         TecConcursos - Comentário do professor sempre "abaixo"
// @namespace    tecconcursos-fix-view
// @version      1.0
// @description  Mantém a visualização do comentário do professor sempre no modo "abaixo" (nunca "ao lado")
// @author       você
// @match        https://www.tecconcursos.com.br/questoes*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  // ---------------------------------------------------------------
  // CONFIG: palavras usadas para identificar os botões no DOM.
  // Se o script não funcionar, veja as instruções no final do chat
  // para descobrir o texto/aria-label certo e ajustar aqui.
  // ---------------------------------------------------------------
  const PALAVRA_ALVO = 'abaixo';   // o que queremos que fique ativo
  const PALAVRA_OPOSTA = 'acima';  // a opção que queremos evitar

  function normaliza(txt) {
    return (txt || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '') // remove acentos
      .trim();
  }

  // Considera "ativo" um elemento com classes/atributos típicos de estado selecionado
  function pareceAtivo(el) {
    if (!el) return false;
    if (el.getAttribute('aria-pressed') === 'true') return true;
    if (el.getAttribute('aria-selected') === 'true') return true;
    const cls = (el.className || '').toString().toLowerCase();
    return /active|selected|is-active|ativo|selecionad/.test(cls);
  }

  // Procura, dentre elementos clicáveis (button, a, [role=button], svg com título/aria-label),
  // aquele cujo texto/aria-label/title contenha a palavra-alvo
  function encontraBotao(palavra) {
    const candidatos = document.querySelectorAll(
      'button, a, [role="button"], [role="tab"], [role="radio"], [title], [aria-label]'
    );
    for (const el of candidatos) {
      const texto = normaliza(
        el.getAttribute('title') ||
        el.getAttribute('aria-label') ||
        el.textContent
      );
      if (texto && texto.includes(normaliza(palavra))) {
        return el;
      }
    }
    return null;
  }

  function garanteVisualizacaoAbaixo() {
    const botaoAbaixo = encontraBotao(PALAVRA_ALVO);
    if (!botaoAbaixo) return; // ainda não carregou / não achou

    if (pareceAtivo(botaoAbaixo)) {
      // já está no modo certo, nada a fazer
      return;
    }

    // Se o botão "abaixo" existe mas não está ativo, clica nele.
    // (Não depende do botão oposto existir/ser encontrado.)
    console.log('[TecConcursos fix] Clicando para fixar visualização "abaixo"...');
    botaoAbaixo.click();
  }

  // A página é uma SPA — roda ao carregar e observa mudanças no DOM
  garanteVisualizacaoAbaixo();

  const observer = new MutationObserver(() => {
    garanteVisualizacaoAbaixo();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Reforço: também checa periodicamente, caso o MutationObserver perca algum caso
  setInterval(garanteVisualizacaoAbaixo, 2000);
})();