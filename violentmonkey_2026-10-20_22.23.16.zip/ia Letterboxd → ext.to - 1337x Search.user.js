// ==UserScript==
// @name         ia Letterboxd → ext.to / 1337x Search
// @namespace    https://letterboxd.com
// @version      1.2.0
// @description  Adiciona botões nas páginas de filmes do Letterboxd para buscar no ext.to e no 1337x
// @author       you
// @match        https://letterboxd.com/film/*
// @grant        GM_openInTab
// @run-at       document-end
// ==/UserScript==

(function () {
  'use strict';

  function getFilmTitle() {
    const h1 = document.querySelector('h1.headline-1.js-widont');
    if (h1) return h1.textContent.trim();

    const meta = document.querySelector('meta[property="og:title"]');
    if (meta) {
      return meta.content.replace(/\s*[•·]\s*Letterboxd\s*$/i, '').replace(/\s*\(\d{4}\)\s*$/, '').trim();
    }

    return null;
  }

  function getFilmYear() {
    // 1. Seletores diretos do DOM (mais confiáveis)
    const selectors = [
      '.releaseyear a',
      '.release-year a',
      '.release-year',
      'a[href*="/films/year/"]',
      '.film-header-lockup .releaseyear',
    ];

    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el) return el.textContent.replace(/[()]/g, '').trim();
    }

    // 2. Título da aba: "The Godfather (1972) • Letterboxd"
    const titleMatch = document.title.match(/\(((19|20)\d{2})\)/);
    if (titleMatch) return titleMatch[1];

    // 3. og:title como último recurso
    const ogTitle = document.querySelector('meta[property="og:title"]')?.content || '';
    const ogMatch = ogTitle.match(/\(((19|20)\d{2})\)/);
    if (ogMatch) return ogMatch[1];

    return '';
  }

  function searchOnExtTo(title, year) {
    const query = year ? `${title} ${year} 1080p` : `${title} 1080p`;
    const url = `https://ext.to/browse/?page_size=100&q=${encodeURIComponent(query)}&with_adult=0`;
    GM_openInTab(url, { active: true });
  }

  function searchOn1337x(title, year) {
    const query = year ? `${title} ${year} 1080p` : `${title} 1080p`;
    const url = `https://1337x.to/search/${encodeURIComponent(query)}/1/`;
    GM_openInTab(url, { active: true });
  }

  function handleSearch(site) {
    const title = getFilmTitle();
    if (!title) {
      alert('[Letterboxd Search] Não foi possível detectar o título do filme.');
      return;
    }
    const year = getFilmYear().replace(/[()]/g, '').trim();

    if (site === 'extto') searchOnExtTo(title, year);
    if (site === '1337x') searchOn1337x(title, year);
  }

  function createButton({ label, title, color, hoverColor, site }) {
    const btn = document.createElement('button');
    btn.title = title;
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14"
           viewBox="0 0 24 24" fill="none" stroke="currentColor"
           stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
           style="display:inline;vertical-align:-2px;margin-right:5px">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
      ${label}
    `;

    Object.assign(btn.style, {
      display:        'inline-flex',
      alignItems:     'center',
      justifyContent: 'center',
      padding:        '6px 14px',
      background:     color,
      color:          '#fff',
      border:         'none',
      borderRadius:   '4px',
      cursor:         'pointer',
      fontSize:       '12px',
      fontWeight:     '700',
      letterSpacing:  '0.05em',
      textTransform:  'uppercase',
      transition:     'background 0.2s',
    });

    btn.addEventListener('mouseenter', () => btn.style.background = hoverColor);
    btn.addEventListener('mouseleave', () => btn.style.background = color);
    btn.addEventListener('click', () => handleSearch(site));

    return btn;
  }

  function injectButtons() {
    if (document.getElementById('letterboxd-search-btns')) return;

    const targets = [
      '.film-rating-wrapper',
      '.film-actions',
      '.col-17 .details',
      'section.film-header-lockup',
      '.film-header-group',
    ];

    let anchor = null;
    for (const sel of targets) {
      anchor = document.querySelector(sel);
      if (anchor) break;
    }

    if (!anchor) {
      anchor = document.querySelector('#content') || document.body;
    }

    const wrapper = document.createElement('div');
    wrapper.id = 'letterboxd-search-btns';
    wrapper.style.cssText = 'margin:8px 0 4px; display:flex; gap:8px; flex-wrap:wrap;';

    wrapper.appendChild(createButton({
      label:      'ext.to',
      title:      'Buscar no ext.to',
      color:      '#00c030',
      hoverColor: '#00a828',
      site:       'extto',
    }));

    wrapper.appendChild(createButton({
      label:      '1337x',
      title:      'Buscar no 1337x',
      color:      '#e05a00',
      hoverColor: '#c04e00',
      site:       '1337x',
    }));

    anchor.insertAdjacentElement('afterend', wrapper);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectButtons);
  } else {
    injectButtons();
  }

  let lastPath = location.pathname;
  const observer = new MutationObserver(() => {
    if (location.pathname !== lastPath) {
      lastPath = location.pathname;
      setTimeout(injectButtons, 800);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

})();