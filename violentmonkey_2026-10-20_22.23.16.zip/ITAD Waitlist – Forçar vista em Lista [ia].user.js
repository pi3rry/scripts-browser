// ==UserScript==
// @name         ITAD Waitlist – Forçar vista em Lista [ia]
// @namespace    https://isthereanydeal.com/
// @version      1.1
// @description  Mantém o botão "List" sempre activo na página Waitlist do IsThereAnyDeal
// @author       você
// @match        https://isthereanydeal.com/waitlist/*
// @match        https://isthereanydeal.com/waitlist
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function () {
  'use strict';

  // Chave usada pelo ITAD para guardar a preferência de vista no localStorage
  const STORAGE_KEY = 'itad-waitlist-layout';
  const DESIRED_LAYOUT = 'list';

  /**
   * Tenta encontrar e clicar o botão "List" se a vista actual não for lista.
   * O ITAD usa Vue; os botões de vista ficam num elemento tipo:
   *   <button class="layout-switch__btn [--active]" data-layout="list">
   * ou variantes semelhantes. O script tenta vários selectores por robustez.
   */
  function forceListView() {
    // Selector 1 – botão com atributo data-layout="list"
    const byData = document.querySelector('button[data-layout="list"], [data-layout="list"]');
    if (byData) {
      activateButton(byData);
      return;
    }

    // Selector 2 – botão cujo texto/aria-label é "list" (case-insensitive)
    const allButtons = Array.from(document.querySelectorAll('button, [role="button"]'));
    const byText = allButtons.find(btn =>
      btn.textContent.trim().toLowerCase() === 'list' ||
      (btn.getAttribute('aria-label') || '').toLowerCase() === 'list' ||
      (btn.getAttribute('title') || '').toLowerCase() === 'list'
    );
    if (byText) {
      activateButton(byText);
      return;
    }

    // Selector 3 – ícone SVG com símbolo de lista (uso/href aponta para #layout-list ou similar)
    const byIcon = document.querySelector('button svg use[href*="list"], button svg use[xlink\\:href*="list"]');
    if (byIcon) {
      activateButton(byIcon.closest('button'));
    }
  }

  /**
   * Clica no botão apenas se ele ainda não estiver activo,
   * evitando cliques desnecessários que poderiam fazer toggle.
   */
  function activateButton(btn) {
    if (!btn) return;
    const isActive =
      btn.classList.contains('active') ||
      btn.classList.contains('--active') ||
      btn.classList.contains('is-active') ||
      btn.getAttribute('aria-pressed') === 'true' ||
      btn.getAttribute('aria-selected') === 'true';

    if (!isActive) {
      btn.click();
    }
  }

  /**
   * Sobrescreve o localStorage para que o ITAD leia sempre "list"
   * quando tentar restaurar a preferência guardada.
   */
  function patchLocalStorage() {
    try {
      // Se o site guardar a preferência, forçamos para 'list'
      const current = localStorage.getItem(STORAGE_KEY);
      if (current !== DESIRED_LAYOUT) {
        localStorage.setItem(STORAGE_KEY, DESIRED_LAYOUT);
      }
    } catch (_) {
      // localStorage pode estar bloqueado – ignoramos silenciosamente
    }
  }

  /**
   * Observa mutações no DOM para reagir quando o Vue renderizar
   * os botões de vista (acontece após o carregamento dos dados).
   */
  function waitForButtons() {
    patchLocalStorage();

    // Tentativa imediata
    forceListView();

    // Observer para quando o Vue injectar o conteúdo dinamicamente
    const observer = new MutationObserver(() => {
      forceListView();
      patchLocalStorage();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Para após 10 s para não correr indefinidamente
    setTimeout(() => observer.disconnect(), 10_000);
  }

  // Ponto de entrada
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', waitForButtons);
  } else {
    waitForButtons();
  }

  // Garante também ao navegar com history.pushState (SPA)
  const _pushState = history.pushState.bind(history);
  history.pushState = function (...args) {
    _pushState(...args);
    setTimeout(waitForButtons, 500);
  };

  window.addEventListener('popstate', () => setTimeout(waitForButtons, 500));
})();