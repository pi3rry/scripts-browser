// ==UserScript==
// @name         ia Letterboxd - Remover espaço e imagem de fundo
// @namespace    https://letterboxd.com/
// @version      1.1
// @description  Remove o espaço entre a capa do filme e a barra de topo, e oculta a imagem de fundo (backdrop)
// @author       Você
// @match        https://letterboxd.com/film/*
// @grant        GM_addStyle
// ==/UserScript==

(function () {
  'use strict';

  GM_addStyle(`
    /* Remove o espaço/padding que empurra o hero da capa para baixo da navbar */
    #content,
    .site-body,
    .site-body-inner,
    section.film-page,
    .film-header-group,
    .film-header,
    [class*="film-poster-container"],
    .poster-list,
    .film-page .section,
    .section-header {
      margin-top: 0 !important;
      padding-top: 0 !important;
    }

    /* O backdrop/banner de fundo do filme */
    .film-header-lockup {
      margin-top: 0 !important;
      padding-top: 0 !important;
    }

    /* Container da imagem de topo (backdrop) */
    .backdrop-container,
    #backdrop-container,
    [id^="backdrop"],
    .film-hero,
    .film-backdrop {
      margin-top: 0 !important;
      top: 0 !important;
    }

    /* Ocultar a imagem de fundo (backdrop) completamente */
    .backdrop-container,
    #backdrop-container,
    [id^="backdrop"],
    .film-backdrop,
    .film-hero,
    .react-component-backdrop,
    div[data-backdrop],
    .film-header-lockup::before,
    .film-header-lockup::after {
      display: none !important;
      background-image: none !important;
      background: none !important;
      opacity: 0 !important;
    }
  `);

  // Fallback via JS: encontra o elemento com padding/margin-top e remove
  function removeGap() {
    const selectors = [
      '.film-header-lockup',
      '.film-hero',
      '.backdrop-container',
      '#backdrop-container',
      '#content',
      '.site-body',
    ];

    selectors.forEach(sel => {
      const el = document.querySelector(sel);
      if (el) {
        el.style.marginTop = '0';
        el.style.paddingTop = '0';
      }
    });
  }

  // Remove a imagem de fundo (backdrop) via JS
  function removeBackdrop() {
    const backdropSelectors = [
      '.backdrop-container',
      '#backdrop-container',
      '.film-backdrop',
      '.film-hero',
      '[id^="backdrop"]',
      'div[data-backdrop]',
      '.react-component-backdrop',
    ];

    backdropSelectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        el.style.display = 'none';
        el.style.backgroundImage = 'none';
        el.style.background = 'none';
      });
    });

    // Remove background-image de qualquer elemento que o tenha no header do filme
    const header = document.querySelector('.film-header-lockup, .film-header');
    if (header) {
      header.style.backgroundImage = 'none';
      header.querySelectorAll('*').forEach(child => {
        const bg = window.getComputedStyle(child).backgroundImage;
        if (bg && bg !== 'none') {
          child.style.backgroundImage = 'none';
        }
      });
    }
  }

  function runAll() {
    removeGap();
    removeBackdrop();
  }

  // Executa assim que o DOM estiver pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runAll);
  } else {
    runAll();
  }

  // Observa mudanças dinâmicas (Letterboxd usa PJAX)
  const observer = new MutationObserver(runAll);
  observer.observe(document.body, { childList: true, subtree: true });
})();