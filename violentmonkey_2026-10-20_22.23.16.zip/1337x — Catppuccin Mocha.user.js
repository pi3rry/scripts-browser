// ==UserScript==
// @name         1337x — Catppuccin Mocha
// @namespace    https://github.com/catppuccin/catppuccin
// @version      1.1.0
// @description  Aplica o tema Catppuccin Mocha no 1337x.to (fundo branco e abas vermelhas corrigidos)
// @author       gerado por Claude
// @match        https://1337x.to/*
// @match        https://www.1337x.to/*
// @match        https://1337x.st/*
// @match        https://x1337x.ws/*
// @match        https://x1337x.eu/*
// @match        https://x1337x.se/*
// @grant        GM_addStyle
// @run-at       document-start
// ==/UserScript==

(function () {
  'use strict';

  // ── Catppuccin Mocha palette ──────────────────────────────────────────────
  const BASE     = '#1e1e2e';
  const MANTLE   = '#181825';
  const CRUST    = '#11111b';
  const SURFACE0 = '#313244';
  const SURFACE1 = '#45475a';
  const SURFACE2 = '#585b70';
  const OVERLAY0 = '#6c7086';
  const OVERLAY1 = '#7f849c';

  const TEXT     = '#cdd6f4';
  const SUBTEXT1 = '#bac2de';
  const SUBTEXT0 = '#a6adc8';

  const MAUVE    = '#cba6f7';
  const RED      = '#f38ba8';
  const GREEN    = '#a6e3a1';
  const BLUE     = '#89b4fa';
  const LAVENDER = '#b4befe';
  const YELLOW   = '#f9e2af';
  const PEACH    = '#fab387';
  const TEAL     = '#94e2d5';
  const SKY      = '#89dceb';

  GM_addStyle(`
    /* ═══════════════════════════════════════════════
       CSS VARS
    ═══════════════════════════════════════════════ */
    :root {
      --ctp-base:     ${BASE};
      --ctp-mantle:   ${MANTLE};
      --ctp-crust:    ${CRUST};
      --ctp-s0:       ${SURFACE0};
      --ctp-s1:       ${SURFACE1};
      --ctp-s2:       ${SURFACE2};
      --ctp-ov0:      ${OVERLAY0};
      --ctp-ov1:      ${OVERLAY1};
      --ctp-text:     ${TEXT};
      --ctp-sub1:     ${SUBTEXT1};
      --ctp-sub0:     ${SUBTEXT0};
      --ctp-mauve:    ${MAUVE};
      --ctp-blue:     ${BLUE};
      --ctp-green:    ${GREEN};
      --ctp-red:      ${RED};
      --ctp-yellow:   ${YELLOW};
      --ctp-peach:    ${PEACH};
      --ctp-lavender: ${LAVENDER};
      --ctp-teal:     ${TEAL};
      --ctp-sky:      ${SKY};
    }

    /* ═══════════════════════════════════════════════
       NUCLEAR OVERRIDE — elimina qualquer branco/preto inline
    ═══════════════════════════════════════════════ */
    * {
      scrollbar-color: var(--ctp-s1) var(--ctp-mantle);
      scrollbar-width: thin;
    }

    /* captura todos os elementos com bg branco, cinza claro ou bg inline vazio */
    *:not(img):not(video):not(canvas):not(svg):not(iframe) {
      background-color: revert;
    }

    html, body {
      background-color: var(--ctp-base) !important;
      color: var(--ctp-text) !important;
    }

    /* Qualquer coisa com fundo branco / cinza claro */
    [style*="background:#fff"],[style*="background: #fff"],
    [style*="background:#FFF"],[style*="background: #FFF"],
    [style*="background:white"],[style*="background: white"],
    [style*="background:White"],[style*="background: White"],
    [style*="background:#ffffff"],[style*="background: #ffffff"],
    [style*="background:#FFFFFF"],[style*="background: #FFFFFF"],
    [style*="background-color:#fff"],[style*="background-color: #fff"],
    [style*="background-color:#FFF"],[style*="background-color: #FFF"],
    [style*="background-color:white"],[style*="background-color: white"],
    [style*="background-color:#ffffff"],[style*="background-color: #ffffff"],
    [style*="background-color:#FFFFFF"],[style*="background-color: #FFFFFF"],
    [style*="background-color:#f9f9f9"],[style*="background-color: #f9f9f9"],
    [style*="background-color:#f5f5f5"],[style*="background-color: #f5f5f5"],
    [style*="background-color:#efefef"],[style*="background-color: #efefef"],
    [style*="background-color:#eee"],[style*="background-color: #eee"],
    [style*="background-color:#e9e9e9"],[style*="background-color: #e9e9e9"] {
      background-color: var(--ctp-mantle) !important;
    }

    /* Texto preto inline */
    [style*="color:#000"],[style*="color: #000"],
    [style*="color:#000000"],[style*="color: #000000"],
    [style*="color:black"],[style*="color: black"],
    [style*="color:#111"],[style*="color: #111"],
    [style*="color:#222"],[style*="color: #222"],
    [style*="color:#333"],[style*="color: #333"] {
      color: var(--ctp-text) !important;
    }

    a, a:visited { color: var(--ctp-blue) !important; }
    a:hover      { color: var(--ctp-mauve) !important; }

    /* ═══════════════════════════════════════════════
       HEADER / NAVBAR
    ═══════════════════════════════════════════════ */
    header, .header, #header,
    nav, .navbar, .top-nav, .nav-top, .main-header,
    .header-wrapper, #top-header, .site-header {
      background: var(--ctp-crust) !important;
      border-bottom: 1px solid var(--ctp-s0) !important;
      color: var(--ctp-text) !important;
    }

    .logo, .logo a, .site-logo, #logo, #logo a,
    .logo-text, .brand, .brand a {
      color: var(--ctp-mauve) !important;
      text-shadow: 0 0 12px color-mix(in srgb, ${MAUVE} 40%, transparent) !important;
    }

    nav a, .nav a, .main-nav a, header a, .header a,
    .navbar-nav a, .nav-item a, .menu-item a {
      color: var(--ctp-sub1) !important;
    }
    nav a:hover, .nav a:hover, header a:hover,
    .navbar-nav a:hover, .menu-item a:hover {
      color: var(--ctp-mauve) !important;
    }

    nav a.active, nav li.active a, .nav a.active, .nav li.active a,
    .menu-item.current a, .nav-item.active a {
      color: var(--ctp-mauve) !important;
      border-bottom: 2px solid var(--ctp-mauve) !important;
    }

    /* ═══════════════════════════════════════════════
       ABAS / TABS  ← seção principal da correção
       O 1337x usa abas com fundo vermelho (#c0392b / #e74c3c)
       nas classes: .tab-bar, .tabs, ul.tabs, li.tab, .nav-tabs
    ═══════════════════════════════════════════════ */

    /* Container das abas */
    .tab-bar, .tabs, ul.tabs, .nav-tabs,
    .tab-list, .tablist, [role="tablist"],
    .category-tabs, .sub-tabs, .genre-tabs,
    .tab-wrap, .tabs-wrap, .tabs-container,
    .torrent-tabs, .detail-tabs, .page-tabs {
      background: var(--ctp-crust) !important;
      border-bottom: 2px solid var(--ctp-s0) !important;
    }

    /* Cada aba individual */
    .tab-bar li, .tabs li, ul.tabs li,
    .nav-tabs li, .tab-list li,
    .tab-bar a, .tabs a, ul.tabs a,
    .nav-tabs a, .tab-list a,
    .tab-bar .tab, .tabs .tab, .nav-tabs .nav-link,
    [role="tab"] {
      background: var(--ctp-s0) !important;
      color: var(--ctp-sub1) !important;
      border: 1px solid var(--ctp-s1) !important;
      border-bottom: none !important;
      border-radius: 6px 6px 0 0 !important;
      transition: background .15s, color .15s !important;
    }

    /* Aba hover */
    .tab-bar li:hover, .tabs li:hover, ul.tabs li:hover,
    .nav-tabs li:hover, .tab-bar a:hover, .tabs a:hover,
    .nav-tabs a:hover, [role="tab"]:hover {
      background: var(--ctp-s1) !important;
      color: var(--ctp-text) !important;
    }

    /* Aba ATIVA — substitui vermelho por mauve */
    .tab-bar li.active, .tabs li.active, ul.tabs li.active,
    .nav-tabs li.active, .nav-tabs .active,
    .tab-bar a.active, .tabs a.active,
    .nav-tabs a.active, .nav-tabs .nav-link.active,
    .nav-tabs .nav-link.active, [role="tab"].active,
    [role="tab"][aria-selected="true"],
    .tab-bar li.on, .tabs li.on, .tab-bar .tab.on,
    .tab-bar .tab.active, .tab-bar .tab.current,
    .tabs .tab.active, .tabs .tab.on,
    .category-tabs li.active, .category-tabs a.active,
    li.active > a, .tab-active, .current-tab {
      background: var(--ctp-mauve) !important;
      color: var(--ctp-crust) !important;
      border-color: var(--ctp-mauve) !important;
      font-weight: 700 !important;
    }

    /* Painel de conteúdo da aba */
    .tab-content, .tab-pane, .tab-panel,
    [role="tabpanel"] {
      background: var(--ctp-mantle) !important;
      border: 1px solid var(--ctp-s0) !important;
      border-top: none !important;
      color: var(--ctp-text) !important;
    }

    /* ═══════════════════════════════════════════════
       FUNDO BRANCO — containers e wrappers do 1337x
    ═══════════════════════════════════════════════ */
    main, #wrapper, .wrapper, #page-wrapper,
    .main-content, #content, .content,
    .container, .page-content, .inner,
    .inner-wrap, .content-wrap, .page-wrap,
    .site-content, #site-content,
    .torrent-detail-info, .torrent-info-wrap,
    .box-info, .info-box, .torrent-detail,
    .torrent-info, .detail-box, .info-block,
    .box-info-detail, .inner-info, .detail-info,
    .box, .panel, .card, .section,
    .content-area, .content-block,
    .right-content, .left-content,
    .main-wrap, .body-wrap, #body-wrap,
    .inner-content, .inner-page,
    .torrent-detail .box-info,
    .page-content > div, .page-content > section {
      background: var(--ctp-base) !important;
      color: var(--ctp-text) !important;
    }

    /* Blocos de info com borda (caixas da página de detalhe) */
    .box-info, .info-box, .torrent-detail,
    .torrent-detail-info, .box-info-detail,
    .inner-info, .detail-info, .info-block {
      background: var(--ctp-mantle) !important;
      border: 1px solid var(--ctp-s0) !important;
      border-radius: 8px !important;
    }

    .box-info h1, .torrent-detail h1,
    .box-info h2, .torrent-detail h2,
    .box-info h3, .box-info h4 {
      color: var(--ctp-mauve) !important;
    }

    .list, .torrent-detail ul li,
    .info-box ul li, .box-info ul li,
    .info-list li, .detail-list li {
      border-bottom: 1px solid var(--ctp-s0) !important;
      color: var(--ctp-text) !important;
      background: transparent !important;
    }

    /* ═══════════════════════════════════════════════
       SEARCH BAR
    ═══════════════════════════════════════════════ */
    .search-box, .search-form, #search,
    form[action*="search"], .search-wrap,
    .search-bar, .search-container, #search-form {
      background: var(--ctp-mantle) !important;
    }

    input[type="text"], input[type="search"],
    input[type="email"], input[type="password"],
    textarea, select {
      background: var(--ctp-s0) !important;
      color: var(--ctp-text) !important;
      border: 1px solid var(--ctp-s1) !important;
      outline: none !important;
      border-radius: 6px !important;
    }
    input[type="text"]:focus, input[type="search"]:focus,
    input[type="email"]:focus, input[type="password"]:focus,
    textarea:focus, select:focus {
      border-color: var(--ctp-mauve) !important;
      box-shadow: 0 0 0 2px color-mix(in srgb, ${MAUVE} 25%, transparent) !important;
    }
    input::placeholder { color: var(--ctp-ov0) !important; }
    select option { background: var(--ctp-s0) !important; color: var(--ctp-text) !important; }

    button[type="submit"], input[type="submit"],
    .search-btn, .btn-search, .btn-primary {
      background: var(--ctp-mauve) !important;
      color: var(--ctp-crust) !important;
      border: none !important;
      border-radius: 6px !important;
      font-weight: 700 !important;
      cursor: pointer !important;
      transition: filter .15s !important;
    }
    button[type="submit"]:hover, input[type="submit"]:hover,
    .search-btn:hover, .btn-search:hover {
      filter: brightness(1.1) !important;
    }

    /* ═══════════════════════════════════════════════
       TORRENT LIST TABLE
    ═══════════════════════════════════════════════ */
    .table-list-wrap, .table-list, table, .torrent-list {
      background: var(--ctp-mantle) !important;
      border-radius: 8px !important;
      overflow: hidden !important;
      border: 1px solid var(--ctp-s0) !important;
    }

    table thead, thead tr, th, .table-list thead {
      background: var(--ctp-crust) !important;
      color: var(--ctp-mauve) !important;
      border-bottom: 2px solid var(--ctp-s0) !important;
      font-weight: 700 !important;
    }

    table th a, thead th a { color: var(--ctp-mauve) !important; }

    table tbody tr, .table-list tbody tr {
      background: var(--ctp-mantle) !important;
      border-bottom: 1px solid var(--ctp-s0) !important;
      transition: background .12s !important;
    }
    table tbody tr:nth-child(even) {
      background: color-mix(in srgb, ${BASE} 60%, ${MANTLE}) !important;
    }
    table tbody tr:hover { background: var(--ctp-s0) !important; }

    td, th {
      color: var(--ctp-text) !important;
      border-color: var(--ctp-s0) !important;
      background: transparent !important;
    }

    .table-list td:first-child a, td.name a, td.coll-1 a {
      color: var(--ctp-text) !important;
      font-weight: 500 !important;
    }
    .table-list td:first-child a:hover, td.name a:hover, td.coll-1 a:hover {
      color: var(--ctp-mauve) !important;
    }

    td.seeds, .seeds, .table-list .seeds    { color: var(--ctp-green) !important; font-weight: 700 !important; }
    td.leeches, .leeches, .table-list .leeches { color: var(--ctp-red) !important; font-weight: 700 !important; }
    td.size, .size { color: var(--ctp-sub0) !important; }
    td.coll-date, .coll-date { color: var(--ctp-ov1) !important; }

    /* ═══════════════════════════════════════════════
       MAGNET / DOWNLOAD BUTTONS
    ═══════════════════════════════════════════════ */
    .magnet-download a, a[href^="magnet:"],
    .download-button, .btn-download, .download-btn, .magnet-btn {
      background: var(--ctp-green) !important;
      color: var(--ctp-crust) !important;
      border: none !important;
      border-radius: 6px !important;
      font-weight: 700 !important;
      transition: filter .15s !important;
    }
    .magnet-download a:hover, a[href^="magnet:"]:hover,
    .download-button:hover, .btn-download:hover {
      filter: brightness(1.1) !important;
      color: var(--ctp-crust) !important;
    }

    .torrent-detail-info a.btn, .box-info a.btn, a.btn {
      background: var(--ctp-blue) !important;
      color: var(--ctp-crust) !important;
      border-radius: 6px !important;
      font-weight: 700 !important;
      border: none !important;
    }
    .torrent-detail-info a.btn:hover, .box-info a.btn:hover, a.btn:hover {
      filter: brightness(1.1) !important;
      color: var(--ctp-crust) !important;
    }

    /* ═══════════════════════════════════════════════
       SIDEBAR / WIDGETS
    ═══════════════════════════════════════════════ */
    aside, .sidebar, .side-bar, .right-bar, .left-bar {
      background: transparent !important;
    }
    .widget {
      background: var(--ctp-mantle) !important;
      border: 1px solid var(--ctp-s0) !important;
      border-radius: 8px !important;
    }
    .widget-title, .sidebar h2, .sidebar h3, .side-title, .box-title {
      color: var(--ctp-lavender) !important;
      border-bottom: 1px solid var(--ctp-s0) !important;
      padding-bottom: 6px !important;
      font-weight: 700 !important;
      background: transparent !important;
    }
    .widget ul li, .sidebar ul li {
      border-bottom: 1px solid var(--ctp-s0) !important;
      background: transparent !important;
    }
    .widget ul li a, .sidebar ul li a { color: var(--ctp-sub1) !important; }
    .widget ul li a:hover, .sidebar ul li a:hover { color: var(--ctp-mauve) !important; }

    /* ═══════════════════════════════════════════════
       LABELS / CATEGORY PILLS
    ═══════════════════════════════════════════════ */
    .label, .torrent-category, .type-label, .cat-label,
    .badge, .tag, .genre, .category-tag, .cat, .cat-tag {
      background: var(--ctp-s0) !important;
      color: var(--ctp-mauve) !important;
      border-radius: 99px !important;
      padding: 2px 9px !important;
      font-size: .78em !important;
      font-weight: 600 !important;
      border: none !important;
    }

    /* ═══════════════════════════════════════════════
       PAGINATION
    ═══════════════════════════════════════════════ */
    .pagination, .pager, ul.pagination { display: flex !important; gap: 4px !important; }

    .pagination li a, .pagination a, .page-link {
      background: var(--ctp-s0) !important;
      color: var(--ctp-text) !important;
      border: 1px solid var(--ctp-s1) !important;
      border-radius: 6px !important;
      padding: 5px 11px !important;
      transition: background .12s, color .12s !important;
    }
    .pagination li a:hover, .pagination a:hover, .page-link:hover {
      background: var(--ctp-mauve) !important;
      color: var(--ctp-crust) !important;
    }
    .pagination li.active a, .pagination .active .page-link, .pagination .current {
      background: var(--ctp-mauve) !important;
      color: var(--ctp-crust) !important;
      border-color: var(--ctp-mauve) !important;
      font-weight: 700 !important;
    }

    /* ═══════════════════════════════════════════════
       FOOTER
    ═══════════════════════════════════════════════ */
    footer, .footer, #footer {
      background: var(--ctp-crust) !important;
      color: var(--ctp-ov1) !important;
      border-top: 1px solid var(--ctp-s0) !important;
    }
    footer a, .footer a { color: var(--ctp-sub0) !important; }
    footer a:hover, .footer a:hover { color: var(--ctp-mauve) !important; }

    /* ═══════════════════════════════════════════════
       MODALS / POPUPS
    ═══════════════════════════════════════════════ */
    .modal, .popup, .modal-content, .modal-dialog, .overlay-box {
      background: var(--ctp-mantle) !important;
      border: 1px solid var(--ctp-s1) !important;
      border-radius: 10px !important;
      color: var(--ctp-text) !important;
    }
    .modal-header, .popup-header {
      background: var(--ctp-crust) !important;
      border-bottom: 1px solid var(--ctp-s0) !important;
    }
    .modal-footer, .popup-footer {
      background: var(--ctp-crust) !important;
      border-top: 1px solid var(--ctp-s0) !important;
    }

    /* ═══════════════════════════════════════════════
       ALERTS / NOTICES
    ═══════════════════════════════════════════════ */
    .alert, .notice, .message {
      border-radius: 8px !important;
      border-left: 4px solid var(--ctp-mauve) !important;
      background: color-mix(in srgb, ${MAUVE} 12%, ${MANTLE}) !important;
      color: var(--ctp-text) !important;
    }
    .alert-success { border-left-color: var(--ctp-green) !important; }
    .alert-danger, .alert-error { border-left-color: var(--ctp-red) !important; }
    .alert-warning { border-left-color: var(--ctp-yellow) !important; }
    .alert-info { border-left-color: var(--ctp-blue) !important; }

    /* ═══════════════════════════════════════════════
       DROPDOWN MENUS
    ═══════════════════════════════════════════════ */
    .dropdown-menu, .dropdown-content, ul.dropdown, .sub-menu {
      background: var(--ctp-s0) !important;
      border: 1px solid var(--ctp-s1) !important;
      border-radius: 8px !important;
      box-shadow: 0 8px 24px rgba(0,0,0,.4) !important;
    }
    .dropdown-menu a, .dropdown-menu li a, .sub-menu a {
      color: var(--ctp-text) !important;
      padding: 8px 14px !important;
      background: transparent !important;
    }
    .dropdown-menu a:hover, .dropdown-menu li a:hover, .sub-menu a:hover {
      background: var(--ctp-s1) !important;
      color: var(--ctp-mauve) !important;
    }

    /* ═══════════════════════════════════════════════
       COMMENTS
    ═══════════════════════════════════════════════ */
    .comments, .comment, .comment-body, .comment-list li {
      background: var(--ctp-mantle) !important;
      border: 1px solid var(--ctp-s0) !important;
      border-radius: 6px !important;
      color: var(--ctp-text) !important;
    }
    .comment-author, .comment-user { color: var(--ctp-lavender) !important; font-weight: 600 !important; }
    .comment-date { color: var(--ctp-ov1) !important; }

    /* ═══════════════════════════════════════════════
       MISC
    ═══════════════════════════════════════════════ */
    hr { border-color: var(--ctp-s0) !important; }

    ::-webkit-scrollbar { width: 8px; height: 8px; }
    ::-webkit-scrollbar-track { background: var(--ctp-mantle); }
    ::-webkit-scrollbar-thumb { background: var(--ctp-s1); border-radius: 4px; }
    ::-webkit-scrollbar-thumb:hover { background: var(--ctp-s2); }

    ::selection {
      background: color-mix(in srgb, ${MAUVE} 35%, transparent);
      color: var(--ctp-text);
    }
  `);

  // ── JS: corrige elementos com background vermelho inline e estilos injetados ──
  // Roda após o DOM carregar para pegar classes dinâmicas
  function patchRedAndWhite() {
    // Pega todos os elementos e verifica computed style
    const all = document.querySelectorAll('*');
    const redish = /^(#(c0392b|e74c3c|cc0000|ff0000|b71c1c|c62828|d32f2f|f44336|ef5350|e53935)|red|crimson)/i;
    const whitish = /^(#(fff(fff)?|f[89abcdef][89abcdef][89abcdef][89abcdef][89abcdef]|fafafa|f5f5f5|f0f0f0|eeeeee|e0e0e0)|white)/i;

    all.forEach(el => {
      const s = el.style;
      if (s.backgroundColor && redish.test(s.backgroundColor.trim())) {
        s.setProperty('background-color', '#cba6f7', 'important'); // mauve
        s.setProperty('color', '#11111b', 'important'); // crust
      }
      if (s.background && redish.test(s.background.trim())) {
        s.setProperty('background', '#cba6f7', 'important');
        s.setProperty('color', '#11111b', 'important');
      }
      if (s.backgroundColor && whitish.test(s.backgroundColor.trim())) {
        s.setProperty('background-color', '#181825', 'important'); // mantle
      }
      if (s.background && whitish.test(s.background.trim())) {
        s.setProperty('background', '#181825', 'important');
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', patchRedAndWhite);
  } else {
    patchRedAndWhite();
  }

  // Observa mudanças dinâmicas (SPAs / lazy load)
  const observer = new MutationObserver(() => patchRedAndWhite());
  document.addEventListener('DOMContentLoaded', () => {
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
  });

})();