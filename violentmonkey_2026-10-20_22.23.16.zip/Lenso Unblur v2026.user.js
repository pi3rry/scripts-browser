// ==UserScript==
// @name         Lenso Unblur v2026
// @namespace    local.codex
// @version      1.0.1
// @description  Removes client-side blur/lock overlays from Lenso result cards.
// @author       you
// @match        https://lenso.ai/*
// @run-at       document-idle
// @grant        none
// @downloadURL https://update.greasyfork.org/scripts/568007/Lenso%20Unblur%20v2026.user.js
// @updateURL https://update.greasyfork.org/scripts/568007/Lenso%20Unblur%20v2026.meta.js
// ==/UserScript==

(function () {
  'use strict';

  const STYLE_ID = 'gm-lenso-unblur-style';

  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      .result-card .overlay,
      .search-results-list > .overlay {
        display: none !important;
        opacity: 0 !important;
        visibility: hidden !important;
        pointer-events: none !important;
      }

      .result-card .title-container.locked > .title,
      .result-card .title-container .title {
        filter: none !important;
        -webkit-filter: none !important;
      }

      .result-card .result-image-wrapper,
      .result-card .result-image,
      .result-card .result-image-wrapper::before {
        filter: none !important;
        -webkit-filter: none !important;
        backdrop-filter: none !important;
        -webkit-backdrop-filter: none !important;
      }

      .result-card .result-image-wrapper::before {
        content: none !important;
        background: none !important;
        background-image: none !important;
      }
    `;

    document.head.appendChild(style);
  }

  function unlockTree(root) {
    if (!(root instanceof Element || root instanceof Document)) return;

    const locked = root.querySelectorAll ? root.querySelectorAll('.locked') : [];
    locked.forEach((el) => el.classList.remove('locked'));

    const overlays = root.querySelectorAll
      ? root.querySelectorAll('.result-card .overlay, .search-results-list > .overlay')
      : [];
    overlays.forEach((el) => {
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
    });

    const wrappers = root.querySelectorAll
      ? root.querySelectorAll('.result-image-wrapper, [style*="--blur-image-url"]')
      : [];
    wrappers.forEach((el) => {
      el.style.removeProperty('--blur-image-url');
      el.style.setProperty('filter', 'none', 'important');
      el.style.setProperty('-webkit-filter', 'none', 'important');
      el.style.setProperty('backdrop-filter', 'none', 'important');
      el.style.setProperty('-webkit-backdrop-filter', 'none', 'important');
      el.style.setProperty('background-image', 'none', 'important');
    });

    const unlockLabels = root.querySelectorAll
      ? root.querySelectorAll('.domain-details p')
      : [];
    unlockLabels.forEach((p) => {
      if (/^\s*unlock\s+sources\s*$/i.test(p.textContent || '')) {
        const details = p.closest('.domain-details');
        if (details) {
          details.style.setProperty('display', 'none', 'important');
        }
      }
    });
  }

  let queued = false;
  function queueUnlock(target) {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      unlockTree(target || document);
    });
  }

  function start() {
    injectStyle();
    unlockTree(document);

    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        if (m.type === 'childList') {
          m.addedNodes.forEach((n) => {
            if (n instanceof Element) unlockTree(n);
          });
        } else if (m.type === 'attributes' && m.target instanceof Element) {
          unlockTree(m.target);
        }
      }
      queueUnlock(document);
    });

    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['class', 'style']
    });

    setInterval(() => queueUnlock(document), 1500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start, { once: true });
  } else {
    start();
  }
})();
